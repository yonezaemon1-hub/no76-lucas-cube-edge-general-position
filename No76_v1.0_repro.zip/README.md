# No.76 reproducibility archive v1.0

Run `python -B -I verify_public.py` from this directory with Python 3.10+.
The three frozen verifiers, their expected outputs, and mathematical notes are byte-for-byte copies of the v0.1, v0.2, v0.3 lineage nested in v0.4. The v0.4 proof-dependency note and supplemental checker are likewise unmodified. `verify_public.py` and this manifest are new publication wrappers; neither alters the frozen algorithms.

The 9,908 capacity bases (with overlap) are reproduced by the frozen verifiers. Required whole-graph exact bases are n=3,4,6. The negative relaxation at n=6 is treated separately by its exact optimum 11. The historical `PENDING / PRIVATE HOLD` line in frozen software is preserved and should be read as its creation-time status, not as the publication status of v1.0.

Independent AI audit: PACKAGE / DELTA / REQUIRED BASES / INDUCTION PASS; CAPACITY BASES PASS within its documented independent scope; THEOREM conditional PASS. Human peer review was not performed. NOVELTY INCONCLUSIVE. REFERENCES PARTIAL. Copyright (c) 2026 Ryutaro Yonezu. All rights reserved. No Creative Commons or open-source license is granted.

No Windows raw logs, private audit answers or private source ZIPs are included.
