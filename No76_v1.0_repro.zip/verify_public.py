"""Replay the frozen No.76 exact integer certificates; Python 3.10+ stdlib."""
from pathlib import Path
import hashlib, subprocess, sys
root=Path(__file__).resolve().parent
files={p.relative_to(root).as_posix():p for p in root.rglob('*') if p.is_file()}
entries={name:digest for digest,name in (line.split(maxsplit=1) for line in (root/'SHA256SUMS.txt').read_text().splitlines() if line.strip())}
assert set(entries)|{'SHA256SUMS.txt'}==set(files)
for name,digest in entries.items():
    assert hashlib.sha256(files[name].read_bytes()).hexdigest()==digest,name
print('PASS public reproducibility manifest',flush=True)
for d,script in (('v01','verify.py'),('v02','verify_v02.py'),('v03','verify_v03.py')):
    folder=root/'frozen'/d
    output=subprocess.check_output([sys.executable,'-B','-I',str(folder/script)],cwd=folder)
    expected=(folder/'EXPECTED_RESULTS.txt').read_bytes()
    assert output.replace(b'\r\n',b'\n')==expected.replace(b'\r\n',b'\n'),d
    print(f'PASS frozen {d} full replay',flush=True)
folder=root/'addendum'
output=subprocess.check_output([sys.executable,'-B','-I',str(folder/'check_required_dimensions.py')],cwd=folder)
expected=(folder/'EXPECTED_REQUIRED_DIMENSIONS.txt').read_bytes()
assert output.replace(b'\r\n',b'\n')==expected.replace(b'\r\n',b'\n')
print('PASS required dimensions n=3,4,6',flush=True)
print('FINAL PASS PUBLIC REPLAY / AI THEOREM AUDIT CONDITIONAL PASS')
