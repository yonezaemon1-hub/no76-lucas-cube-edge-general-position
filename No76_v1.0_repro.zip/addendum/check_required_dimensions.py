"""Independent finite base check for Lucas cubes n=3,4,6. Standard library."""
from collections import deque
from itertools import combinations, permutations, product

def check(ok, message):
    if not ok:
        raise RuntimeError(message)

def solve(n, target):
    V = [v for v in range(1 << n) if all(not (v >> i & 1 and v >> ((i+1)%n) & 1) for i in range(n))]
    E = list((u,v) for u,v in combinations(V,2) if (u^v).bit_count()==1)
    adj = {v:[] for v in V}
    for u,v in E:
        adj[u].append(v); adj[v].append(u)
    D={}
    for v in V:
        d={v:0}; q=deque([v])
        while q:
            u=q.popleft()
            for w in adj[u]:
                if w not in d:
                    d[w]=d[u]+1; q.append(w)
        check(len(d)==len(V), 'connected'); D[v]=d
    # Exact geodesic criterion: concatenate three ordered, oriented edges
    # and shortest connectors; equality with endpoint distance is necessary
    # and sufficient, even if a connector of a nongood ordering repeats a vertex.
    def forbidden(ids):
        for order in permutations(ids):
            for rev in product((0,1),repeat=3):
                (a,b),(c,d),(e,f) = [E[i][::(-1 if r else 1)] for i,r in zip(order,rev)]
                if D[a][f] == 3+D[b][c]+D[d][e]:
                    return True
        return False
    m=len(E); conflicts=[[0]*m for _ in E]; T=[]
    for triple in combinations(range(m),3):
        if forbidden(triple):
            T.append(triple)
            for i,j,k in permutations(triple):
                conflicts[i][j] |= 1<<k
    W = {i for i,(a,b) in enumerate(E) if a&7==0 and (a^b)&7}
    check(len(W)==target and not any(set(t)<=W for t in T),'lower witness')
    # Enumerate increasing edge subsets, pruning only by remaining count and
    # triples containing two chosen edges. No coloring or external solver.
    nodes=0
    def search(P, chosen):
        nonlocal nodes
        nodes+=1
        if len(chosen)==target+1: return True
        while len(chosen)+P.bit_count()>=target+1:
            low=P&-P; P^=low; i=low.bit_length()-1
            Q=P
            for j in chosen: Q &= ~conflicts[i][j]
            if search(Q,chosen+(i,)): return True
        return False
    check(not search((1<<m)-1,()),'larger set found')
    print(f'PASS n={n} vertices={len(V)} edges={m} triples={len(T)} optimum={target} nodes={nodes}')

if __name__=='__main__':
    for n,t in ((3,3),(4,4),(6,11)): solve(n,t)
    print('FINAL PASS REQUIRED EXACT DIMENSIONS 3,4,6 / PRIVATE HOLD')
