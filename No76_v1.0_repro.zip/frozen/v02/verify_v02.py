"""Exact local-capacity checks; two independent algorithms for local packing."""
from itertools import product, combinations
from functools import lru_cache
from math import prod
from collections import Counter
F=[0,1]
for _ in range(40):F.append(F[-1]+F[-2])
def req(ok,context):
    if not ok:raise ValueError(context)
def records(g):
    if g==1:return [(0,0,1)]
    if g==2:return [(a,a,1) for a in (0,1)]
    return [(p,q,F[g-1-p-q]) for p,q in product((0,1),repeat=2) if F[g-1-p-q]]
# Independent literal path-word enumeration for gap factors.
for g in range(1,13):
    hist=Counter()
    for w in product((0,1),repeat=g-1):
        if any(a*b for a,b in zip(w,w[1:])):continue
        hist[(w[0],w[-1]) if w else (0,0)]+=1
    req(hist==Counter({(p,q):m for p,q,m in records(g)}),('gap',g))
print('PASS gap records vs literal independent words g=1..12')

def legal(x,d,adj,blocked):
    return not(x&blocked) and not any((x>>i&1) and (x>>j&1) for i,j in adj)

def eq(x,i,j):return (x>>i&1)==(x>>j&1)

@lru_cache(None)
def local(d,adj,blocked,pairs,all_pairs):
    V=[x for x in range(1<<d) if legal(x,d,adj,blocked)]
    core={x for x in V if all(eq(x,i,j) for i,j in pairs)}
    E=[(x,y) for x,y in combinations(V,2) if (x^y).bit_count()==1 and all((x^y)&((1<<i)|(1<<j)) or eq(x,i,j) for i,j in pairs)]
    factor=1 if all_pairs else 2
    best=0
    # Algorithm 1: every subset of eligible local edges, then check degrees.
    for mask in range(1<<len(E)):
        N=[[] for _ in range(1<<d)];chosen=[];ok=True
        for i,(x,y) in enumerate(E):
            if mask>>i&1:
                k=(x^y).bit_length()-1;N[x].append(k);N[y].append(k);chosen.append((x,y))
                if len(N[x])>2 or len(N[y])>2:ok=False;break
        if not ok or any(len(N[x])==len(N[y])==2 for x,y in chosen):continue
        if all_pairs and any(len(N[x])==2 and tuple(sorted(N[x])) not in pairs for x in V):continue
        val=2*len(chosen)+factor*sum(not N[x] for x in core)
        best=max(best,val)
    # Algorithm 2: build possible components directly by legal single-bit flips,
    # then pack disjoint vertex masks by exact DP. No edge-subset enumeration.
    neighbors={x:[] for x in V}
    for x in V:
        for k in range(d):
            y=x^(1<<k)
            if legal(y,d,adj,blocked) and all(k in (i,j) or ((x>>i&1)==(x>>j&1)) for i,j in pairs):neighbors[x].append((k,y))
    candidates=set()
    def add(vertices,e):
        mask=sum(1<<x for x in vertices)
        value=2*e-factor*sum(x in core for x in vertices)
        if value>0:candidates.add((mask,value))
    for x in V:
        for k,y in neighbors[x]:add((x,y),1)
        for (k,y),(l,z) in combinations(neighbors[x],2):
            if not all_pairs or tuple(sorted((k,l))) in pairs:add((x,y,z),2)
    @lru_cache(None)
    def pack(available):
        if not available:return 0
        bit=available&-available
        return max([pack(available^bit)]+[w+pack(available^m) for m,w in candidates if m&bit and m&available==m])
    independent=factor*len(core)+pack(sum(1<<x for x in V))
    req(best==independent,('local',d,adj,blocked,pairs,all_pairs,best,independent))
    return best

def cap(gs,pairs,all_pairs):
    d=len(gs);adj=tuple((i,(i+1)%d) for i,g in enumerate(gs) if g==1)
    return sum(prod(w for _,_,w in opts)*local(d,adj,sum(1<<i for i in range(d) if opts[i-1][1] or opts[i][0]),pairs,all_pairs) for opts in product(*(records(g) for g in gs)))

cases=[('one_pair',2,((0,1),),True),('two_overlap',3,((0,1),(0,2)),True),('two_disjoint_A',4,((0,1),(2,3)),True),('two_cross',4,((0,2),(1,3)),True),('two_disjoint_B',4,((0,3),(1,2)),True),('cross_any_number',4,((0,2),(1,3)),False)]
for name,d,pairs,all_pairs in cases:
    margins=[]
    for gs in product(range(1,5),repeat=d):
        n=sum(gs)
        if n<5:continue
        adj={frozenset((i,(i+1)%d)) for i,g in enumerate(gs) if g==1}
        if any(frozenset(p) in adj for p in pairs):continue
        m=2*(F[n]+F[n-2])-cap(gs,pairs,all_pairs)
        req(m>=0,(name,gs,m));margins.append(m)
    print(f'PASS {name} bases={len(margins)} min_doubled_margin={min(margins)}')

# General two- or three-arm core capacity, as in v0.1, now with new ranges.
def fixed(g,a,b):
    if g==1:return [(b,a,1)] if not a*b else []
    if g==2:return [(p,p,1) for p in (0,1) if not(a*p or p*b)]
    return [(p,q,w) for p,q,w in records(g) if not(a*p or q*b)]
def slot(gs,b):
    return sum(prod(w for _,_,w in opts)*max(1,sum(not(opts[j-1][1] or opts[j][0]) for j in range(len(b)))) for opts in product(*(fixed(g,a,c) for g,a,c in zip(gs,b,b[1:]+b[:1]))))
@lru_cache(None)
def literal(gs):
    n=sum(gs);I=[0]
    for g in gs[:-1]:I.append(I[-1]+g)
    M=sum(1<<i for i in I);V={x for x in range(1<<n) if not(x&(x<<1) or (x&1 and x>>(n-1)&1))};h=Counter()
    for x in V:
        h[tuple(x>>i&1 for i in I)]+=max(1,sum((x^(1<<i)) in V for i in I))
    return h
for label,d,condition in [('two_adjacent_or_mixed',2,lambda gs,b:1 in gs or len(set(b))>1),('three_mixed_or_spaced',3,lambda gs,b:len(set(b))>1 or min(gs)>=3)]:
    margins=[]
    for gs in product(range(1,5),repeat=d):
        n=sum(gs)
        if n<3:continue
        for b in product((0,1),repeat=d):
            if any(g==1 and (b[j] or b[(j+1)%d]) for j,g in enumerate(gs)) or not condition(gs,b):continue
            c=tuple(1-x for x in b);h=literal(gs)
            req(slot(gs,b)==h[b] and slot(gs,c)==h[c],('literal',gs,b))
            m=F[n]+F[n-2]-h[b]-h[c];req(m>=0,(label,gs,b,m));margins.append(m)
    print(f'PASS {label} bases={len(margins)} min_margin={min(margins)}')
print('PASS all new finite bases and independent local checks / PRIVATE HOLD')
