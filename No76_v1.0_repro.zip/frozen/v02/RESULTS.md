# No.76 v0.2 — Local star-pair capacity bounds in Lucas cubes

PRIVATE HOLD / NOVELTY INCONCLUSIVE / REFERENCES PARTIAL. This is an additive research note, not an all-dimension classification. The exact frozen v0.1 package is included. No.75 is unchanged. All new general implications require independent mathematics audit; Windows has not been run.

## 1. Model and inheritance

Use the model and Fibonacci indexing in FROZEN_V01.zip, RESULTS.md. Write K_n=F_n+F_{n-2}. The v0.1 construction gives gp_e(Lambda_n)>=K_n for n>=4, and exact finite values through n=9 were established there. For n>=5 the previous conditional upper bounds cover sets using at most two colors, matchings, degree >=4, and three-arm stars with adjacent colors. We use the self-contained star-forest and projection lemmas B and C from v0.1, not No.75's main theorem. All following arguments are for sets S using at least three colors, so the selected graph is a star forest by Lemma B. A color means a flipped coordinate.

## 2. Two-arm projection and capacity

The proof of Lemma C in v0.1 works without change for d=2 provided the edge under consideration has color outside the chosen pair. Indeed, select the chosen two arms i,j of a star with center v. For an edge f of color k outside {i,j}, a disagreement with v on exactly one of i,j permits orienting the two-edge path through v to end with the same i,j bits as f. Choose the endpoint of f with matching k bit. A shortest connector changes none of these three coordinates, and the concatenation changes every coordinate at most once. This is a forbidden geodesic. Consequently all outside-pair edges lie in the core C consisting of the two complementary patterns of center bits on the pair. Edges in the pair have exactly one endpoint in C (one bit flips). The capacity charging argument of Lemma D therefore works for d=2 also: charge pair-colored edges to the unique core endpoint, and outside-pair edges to distinct leaves of their selected star components. A leaf recipient has no selected pair-colored edge. The bound is the sum over core vertices x of max(1,a(x)), where a counts actual legal flips in the pair.

The gap counting and recurrence in v0.1 also work for d=2 whenever n>=3 (the two cyclic intervals have disjoint interiors). The new verifier exhausts all feasible gap tuples in {1,2,3,4}^2 with n>=3 for which the pair is adjacent or the center bits differ. It compares each fixed-pattern formula against literal legal-word enumeration and actual flips. All 24 bases satisfy capacity <=K_n, minimum margin zero. When reducing a gap >=5, adjacency status and the center pattern are preserved and both smaller sums are >=4. The identical Fibonacci recurrence for target and capacity proves the conditional upper bound at every n>=3. A triple with fewer than three selected colors was already covered by v0.1 for n>=5.

**Theorem Q (conditional).** If S contains a two-arm star with adjacent colors or unequal center bits on the pair, then |S|<=K_n. In particular, to seek a counterexample at n>=5 it suffices to consider stars whose every pair of arms is nonadjacent and has equal center bits. This is a genuine restriction, not a claim that all remaining configurations exist.

## 3. Three-arm supplementary cases

Use the original d=3 core capacity of Lemma D. The new verifier tests all feasible base triples with mixed center projection (not constant) or with every gap at least 3, and compares against literal enumeration. All 205 bases satisfy the target with minimum margin 4. Gap reduction preserves these conditions: reducing g>=5 leaves g>=3, and bits remain unchanged. By the recurrence, the conditional upper bound holds for every such tuple.

**Theorem R (conditional).** A three-arm star with nonconstant center projection or with all cyclic gaps at least 3 forces |S|<K_n. Together with v0.1, if a counterexample has maximum degree 3, every three-arm star must have constant center projection and at least one gap equal to 2; no gap is 1. This is a necessary condition, not a classification of remaining optima.

## 4. Local capacity by two-arm color pairs

Assume maximum selected degree 2 and that Theorem Q does not apply. Each two-arm component supplies an unordered pair {i,j} with nonadjacent coordinates and equal center bits. Let P be any nonempty collection of such pairs, and I the union of their coordinates. The two-arm projection lemma gives the following constraints simultaneously:
- Every selected edge of color k outside I has both endpoints satisfying equality of bits on every pair in P. Call this the core condition.
- A selected edge of color k in I satisfies the equality for every pair in P not containing k.
These are only necessary conditions. Ignoring additional forbidden triples is safe for an upper bound.

Partition legal words into fibers by fixing all coordinates outside I. Within a fiber, vertices are legal assignments to I. The eligible local edges are exactly those passing the above necessary conditions. A selected local subgraph is a forest of stars of maximum degree 2. Let A be any such local subgraph, e(A) its edge count, and z(A) the number of core vertices of local degree zero.

### 4.1 Arbitrary number of pairs

Charge every selected edge outside I to a leaf of its selected component (arbitrary endpoint if a singleton edge). Each recipient is core and has local degree zero; recipients are distinct. Therefore, adding the local edge counts and these charges over fibers proves

    2|S| <= sum_fibers max_A [2 e(A)+2 z(A)].

All maxima are finite local optimizations. They are over relaxations, not assumptions about the existence of globally compatible edges.

### 4.2 All two-arm pairs specified

If P is the complete set of pairs occurring at degree-2 vertices of S, every exterior edge is isolated in the selected graph: otherwise its color would belong to a pair in P, contradicting its being outside I. Count its two endpoints; both are distinct core vertices of local degree zero. Also require that every local degree-2 vertex uses a pair in P, since that pair occurs in S. Then

    2|S| <= sum_fibers max_A [2 e(A)+ z(A)],

with this additional local restriction. No exterior edges are assumed to be actually available at the counted vertices, so the bound remains a relaxation.

## 5. Cyclic gap summation, recurrence and certificate

Write d=|I|, list I cyclically, and let its cyclic gaps g_j be positive with sum n. For each fixed outside configuration, record the bits p,q adjacent to the selected endpoints inside each gap. For g=1 there is no outside vertex; use sentinel p=q=0, and enforce the adjacency of the two selected bits separately. For g=2 the one outside bit gives records p=q=0 and p=q=1, each multiplicity one. For g>=3 the number of legal internal words with ends p,q is F_{g-1-p-q}, including zeros. Gaps are independent before assigning the selected bits. A selected coordinate is blocked from value 1 if one of its outside neighbors is 1. Gap 1 imposes a direct adjacency between selected bits. Thus the local graph, core and objective depend only on the blocked mask and the gap-1 adjacencies, not on other gap lengths. The total local capacity is obtained by summing over record combinations with product multiplicities.

For a gap g>=5, the records can be considered the same four possible bit pairs, with zero multiplicities allowed, in both smaller gaps g-1,g-2 (both >=3). No gap-1 adjacency changes. Hence the doubled capacity satisfies the Fibonacci recurrence in each such gap; 2K_n does too. Restricting pairs to nonadjacent coordinates is preserved because gaps are only reduced to lengths >=3. For n>=5 and d>=3, a nonbase gap has smaller total n-2>=5; for one nonadjacent pair d=2, the other gap is >=2 and n-2>=5. Strong induction therefore extends every checked base inequality to all n>=5 for these cases.

The verifier computes the local optima twice: (i) enumeration of eligible local edge subsets with exact degree and star checks; (ii) enumeration of one-edge and two-arm components directly from legal flips and exact maximum-weight vertex-disjoint packing DP. For (ii), start from all core vertices credited, then a component on vertex set B with e edges contributes 2e - factor*|B intersect core|, with factor 1 or 2 as appropriate. Nonpositive contributions may be omitted because unused vertices retain their initial credit and no component is obligatory. Independent gap word enumeration checks the multiplicities through g=12. Both methods agree on every local optimum used in the finite cases. All calculations are integers; no numerical solver is used.

### Theorem S (conditional upper bounds for maximum degree 2)

1. If precisely one pair occurs, use section 4.2 with d=2. All 8 feasible base cases with n>=5 have doubled margin >=2.
2. If precisely two distinct pairs occur, either they share a coordinate (d=3), or they are disjoint (d=4). Relabel the cyclic order of their coordinates; the shared-coordinate case is covered by placing the shared coordinate first and using pairs (0,1),(0,2). For disjoint pairs there are exactly three pairings of four cyclically ordered coordinates, all tested separately. The complete-pair-set bound of section 4.2 passes all 36, 144, 255, 144 base cases respectively, doubled margins at least 2, 2, 1, 2 respectively.
3. If two pairs cross in cyclic order (four distinct coordinates i,j,k,l in order, with pairs {i,k},{j,l}), use section 4.1; no assumption on other pairs. All 255 bases have nonnegative doubled margin, minimum zero.

Each of these gives |S|<=K_n for all n>=5 by the preceding recurrence. Base enumeration excludes n<5 only, since the induction for nonbase tuples never enters n<5. This is a computer-assisted conditional upper theorem, not a solution of the unrestricted problem.

## 6. Status and limitations

New exact base checks: 1071 total across the eight categories, including overlap of categories; not 1071 distinct graph instances. Frozen v0.1 contains the earlier 1895 base checks and finite optima through n=9. No new complete finite optimum is certified in v0.2. The maximum-degree-2 residual case is a family of at least three distinct nonadjacent equal-center-bit pairs, with no crossings. Maximum degree 3 residual: every three-arm star has constant center projection, no adjacent arms, and at least one gap 2; Theorem Q also excludes unequal-bit or adjacent two-arm stars anywhere in S. These necessary conditions do not imply existence of counterexamples. This note does not prove the full conjecture.

No new literature search was performed for the present local-capacity lemmas. Primary reference and prior searches are documented in frozen v0.1; novelty remains INCONCLUSIVE. Windows and independent AI/human audit are pending. Run `python -B -I verify_v02.py` and compare to EXPECTED_RESULTS.txt; stdlib only. Source package frozen unchanged; retain the old finite certificates separately. All rights reserved.
