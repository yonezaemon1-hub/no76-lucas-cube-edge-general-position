"""Exact finite bases for the all-dimension Lucas cube upper proof candidate."""
from itertools import combinations,product
from functools import lru_cache
from collections import Counter
from math import prod
F=[0,1]
for _ in range(80):F.append(F[-1]+F[-2])
def records(g):
 if g==1:return [(0,0,1)]
 if g==2:return [(a,a,1) for a in (0,1)]
 return [(p,q,F[g-1-p-q]) for p,q in product((0,1),repeat=2) if F[g-1-p-q]]
def patts(d,m):
 for P in combinations(combinations(range(d),2),m):
  if len(set(sum(P,())))!=d:continue
  if any(a<b<c<e or b<a<e<c for (a,c),(b,e) in combinations(P,2)):continue
  def tr(s,r):return tuple(sorted(tuple(sorted(((s*a+r)%d,(s*b+r)%d))) for a,b in P))
  if P!=min(tr(s,r) for s in (-1,1) for r in range(d)):continue
  yield P
@lru_cache(None)
def local(d,adj,blocked,P,factor,maxdeg=2):
 V=[x for x in range(1<<d) if not x&blocked and not any(x>>a&1 and x>>b&1 for a,b in adj)]
 equal=lambda x,a,b: (x>>a&1)==(x>>b&1)
 core={x for x in V if all(equal(x,a,b) for a,b in P)}
 V=set(V);opts={}
 for x in V:
  N=[(k,x^(1<<k)) for k in range(d) if x^(1<<k) in V and all(k in (a,b) or equal(x,a,b) for a,b in P)]
  for j in range(1,maxdeg+1):
   for ns in combinations(N,j):
    if factor==1 and j>=2 and any(p not in P for p in combinations((k for k,y in ns),2)):continue
    B=[x]+[y for k,y in ns];mask=sum(1<<i for i in B);w=2*j-factor*sum(i in core for i in B)
    if w>0:opts[mask]=max(w,opts.get(mask,0))
 by={x:[(m,w) for m,w in opts.items() if m>>x&1] for x in V}
 @lru_cache(None)
 def rec(A):
  if not A:return 0
  b=A&-A;x=b.bit_length()-1
  return max([rec(A^b)]+[w+rec(A^m) for m,w in by[x] if A&m==m])
 active=0
 for m in opts:active|=m
 return factor*len(core)+rec(active)
@lru_cache(None)
def masks(gs):
 d=len(gs);h=Counter()
 for os in product(*(records(g) for g in gs)):
  h[sum(1<<i for i in range(d) if os[i-1][1] or os[i][0])]+=prod(w for p,q,w in os)
 return h

def cap(gs,P,factor):
 d=len(gs);adj=tuple(sorted(tuple(sorted((i,(i+1)%d))) for i,g in enumerate(gs) if g==1))
 return sum(m*local(d,adj,b,P,factor) for b,m in masks(gs).items())

@lru_cache(None)
def alt(d,adj,b,P,factor,D):
 V=[x for x in range(1<<d) if not x&b and not any(x>>i&1 and x>>j&1 for i,j in adj)]
 C={x for x in V if all(x>>i&1==x>>j&1 for i,j in P)}
 E=[(x,y,(x^y).bit_length()-1) for x,y in combinations(V,2) if (x^y).bit_count()==1 and all((x^y)&((1<<i)|(1<<j)) or x>>i&1==x>>j&1 for i,j in P)]
 # independently enumerate edge subsets, using hereditary pruning
 N=[0]*(1<<d);degrees=[0]*(1<<d);colors=[0]*(1<<d)
 best=0;Nedges=len(E)
 def can(x,y,k):
  if degrees[x]>=D or degrees[y]>=D or degrees[x] and degrees[y]:return False
  # a new edge cannot make x degree >=2 with any selected neighbor of degree >=2
  for u in (x,y):
   if degrees[u]:
    t=N[u]
    while t:
     bit=t&-t;t-=bit
     if degrees[bit.bit_length()-1]>=2:return False
    if factor==1:
     for j in range(d):
      if colors[u]>>j&1 and tuple(sorted((j,k))) not in P:return False
  return True
 def rec(i,val):
  nonlocal best
  if val+2*(Nedges-i)<=best:return
  if i==Nedges:
   best=max(best,val);return
  x,y,k=E[i]
  if can(x,y,k):
   delta=2-factor*((x in C and degrees[x]==0)+(y in C and degrees[y]==0))
   for u,v in ((x,y),(y,x)):
    degrees[u]+=1;N[u]^=1<<v;colors[u]^=1<<k
   rec(i+1,val+delta)
   for u,v in ((x,y),(y,x)):
    degrees[u]-=1;N[u]^=1<<v;colors[u]^=1<<k
  rec(i+1,val)
 rec(0,0)
 return factor*len(C)+best

def check(ok,ctx):
 if not ok:raise ValueError(ctx)
def canonical(P,d):
 return min(tuple(sorted(tuple(sorted(((s*a+r)%d,(s*b+r)%d))) for a,b in P)) for s in (-1,1) for r in range(d))
# Independently aggregate actual short-gap words via OR convolution.
@lru_cache(None)
def literal_masks(gs):
 d=len(gs);h={0:1}
 for i,g in enumerate(gs):
  r=Counter()
  for w in product((0,1),repeat=g-1):
   if any(a*b for a,b in zip(w,w[1:])):continue
   block=0 if not w else (w[0]<<i)|(w[-1]<<((i+1)%d))
   r[block]+=1
  hh=Counter()
  for b,m in h.items():
   for c,k in r.items():hh[b|c]+=m*k
  h=hh
 return h
@lru_cache(None)
def value(d,adj,b,P,factor,D,disjoint):
 if disjoint:
  V=[x for x in range(1<<d) if not x&b and not any(x>>i&1 and x>>j&1 for i,j in adj)]
  C={x for x in V if all(x>>i&1==x>>j&1 for i,j in P)}
  E=[(x,y) for x,y in combinations(V,2) if (x^y).bit_count()==1 and all((x^y)&((1<<i)|(1<<j)) or x>>i&1==x>>j&1 for i,j in P)]
  check(all((x in C)!=(y in C) for x,y in E),('disjoint charging',adj,b,P))
  return 4*len(C)
 x=local(d,adj,b,P,factor,D);y=alt(d,adj,b,P,factor,D)
 check(x==y,('independent local',d,adj,b,P,factor,D,x,y))
 return x

def sweep(label,d,P,factor,D,disjoint=False):
 vals=[]
 for gs in product(range(1,5),repeat=d):
  n=sum(gs);adj=tuple(sorted(tuple(sorted((i,(i+1)%d))) for i,g in enumerate(gs) if g==1))
  if n<5 or any(p in adj for p in P):continue
  h=masks(gs);check(h==literal_masks(gs),('gap multiplicities',gs))
  z=sum(w*value(d,adj,b,P,factor,D,disjoint) for b,w in h.items())
  m=2*(F[n]+F[n-2])-z;vals.append((m,gs))
 neg=[(m,gs) for m,gs in vals if m<0]
 # Only one known exceptional finite base; it cannot be reached from a nonbase tuple.
 if neg:
  check(label=='D3_extra' and d==5 and P==((0,1),(0,3),(1,3),(2,4)) and neg==[(-2,(2,1,1,1,1))],('unexpected failure',label,P,neg))
  check(all(max(gs)<=2 and sum(gs)==6 for m,gs in neg),('exception not isolated',neg))
 print(f'{label} d={d} P={P} bases={len(vals)} min={min(m for m,gs in vals)} negatives={neg}')
 return len(vals),len(neg)

if __name__=='__main__':
 count=0;bad=0;classes=0
 for d in range(3,7):
  for P in patts(d,3):
   a,b=sweep('D2_three_noncross',d,P,2,2,d==6);count+=a;bad+=b;classes+=1
 check((count,bad,classes)==(5463,0,8),('D2 totals',count,bad,classes))
 print('PASS D2 bases=5463 dihedral_classes=8 negatives=0')
 a,b=sweep('D3_complete_triangle',3,((0,1),(0,2),(1,2)),1,3)
 count=a;bad=b;classes=1
 for d in (4,5):
  seen=set()
  for T in combinations(range(d),3):
   for p in combinations(range(d),2):
    if set(p)<=set(T) or len(set(T)|set(p))!=d:continue
    P=canonical(tuple(sorted((*combinations(T,2),p))),d)
    if P in seen:continue
    seen.add(P);a,b=sweep('D3_extra',d,P,2,3);count+=a;bad+=b;classes+=1
 check((count,bad,classes)==(1479,1,5),('D3 totals',count,bad,classes))
 print('PASS D3 bases=1479 dihedral_classes=5 one isolated exception n=6 (requires frozen exact certificate)')
 print('PASS local packing vs edge-subset enumeration (d<=5); disjoint-pair charging d=6; gap words vs OR convolution')
 print('FINAL PASS 6942 new bases / one handled finite exception / GENERAL PROOF REQUIRES AUDIT / PRIVATE HOLD')
