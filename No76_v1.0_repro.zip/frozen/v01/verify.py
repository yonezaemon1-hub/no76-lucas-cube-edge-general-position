"""Exact integer verification. Python 3.10+, stdlib only."""
from itertools import combinations, product
from collections import deque, Counter
from functools import lru_cache
from math import prod

F=[0,1]
for _ in range(40):F.append(F[-1]+F[-2])
def require(ok, detail):
    if not ok:raise ValueError(detail)

def legal(v,n):return not(v&(v<<1) or (v&1 and v>>(n-1)&1))
@lru_cache(None)
def words(n):return tuple(v for v in range(1<<n) if legal(v,n))

def graph(n):
    V=words(n)
    E=[(x,y) for x,y in combinations(V,2) if (x^y).bit_count()==1]
    A={v:[] for v in V}
    for i,(x,y) in enumerate(E):A[x].append((y,i));A[y].append((x,i))
    T=set()
    # All shortest-path triples, by propagation of singletons/pairs in BFS DAGs.
    for s in V:
        D={s:0};Q=deque([s]);order=[]
        while Q:
            x=Q.popleft();order.append(x)
            for y,_ in A[x]:
                if y not in D:D[y]=D[x]+1;Q.append(y)
        require(len(D)==len(V) and all(D[v]==(s^v).bit_count() for v in V),('distance',n,s))
        first={x:set() for x in V};pairs={x:set() for x in V}
        for x in order:
            for y,i in A[x]:
                if D[y]!=D[x]+1:continue
                T.update(tuple(sorted((a,b,i))) for a,b in pairs[x])
                pairs[y].update(pairs[x]);pairs[y].update((a,i) for a in first[x])
                first[y].update(first[x]);first[y].add(i)
    return V,E,T

def prove_upper(E,T,witness):
    m=len(E);allmask=(1<<m)-1;B=[[0]*m for _ in E]
    for a,b,c in T:
        for i,j,k in ((a,b,c),(b,a,c),(a,c,b),(c,a,b),(b,c,a),(c,b,a)):B[i][j]|=1<<k
    W=set(witness);require(not any(all(i in W for i in t) for t in T),'invalid witness')
    target=len(W);nodes=0
    def rec(P,A,size):
        nonlocal nodes
        nodes+=1
        require(size<=target, 'counterexample')
        if size+P.bit_count()<=target:return
        # Proper greedy coloring of the current pair-compatibility graph.
        order=[];bounds=[];k=0;R=P
        while R:
            k+=1;Q=R
            while Q:
                bit=Q&-Q;v=bit.bit_length()-1;order.append(v);bounds.append(k);R^=bit;Q&=~(bit|A[v])
        for v,k in zip(reversed(order),reversed(bounds)):
            if size+k<=target:return
            bit=1<<v;N=P&A[v]
            require(size+1<=target,'counterexample')
            if size+1+N.bit_count()>target:
                AA=A.copy();R=N
                while R:
                    x=R&-R;R^=x;j=x.bit_length()-1;AA[j]&=~B[v][j]
                rec(N,AA,size+1)
            P^=bit
    rec(allmask,[allmask^(1<<i) for i in range(m)],0)
    return nodes

# A second triple predicate, using the coordinate monotonicity criterion.
def triple_by_coordinates(edges,n):
    t=[(x,(x^y).bit_length()-1) for x,y in edges]
    if len({e[1] for e in t})!=3:return False
    for a,b,c in ((t[0],t[1],t[2]),(t[0],t[2],t[1]),(t[1],t[0],t[2])):
        i,j,k=(1<<e[1] for e in (a,b,c));mask=((1<<n)-1)^(i|j|k)
        if (b[0]^c[0])&i or (a[0]^b[0])&k:continue
        if (a[0]^b[0])&(b[0]^c[0])&mask:continue
        if not (a[0]^c[0])&j:continue
        return True
    return False

# Exact small dimensions and independent triple-generator comparison.
for n in range(3,10):
    V,E,T=graph(n)
    T2={t for t in combinations(range(len(E)),3) if triple_by_coordinates([E[i] for i in t],n)}
    require(T==T2,('triple generators',n,len(T),len(T2)))
    W=[i for i,(x,y) in enumerate(E) if (x^y)&7 and x&7==0]
    target=F[n]+F[n-2];require(len(W)==target,('witness size',n))
    nodes=prove_upper(E,T,W)
    print(f'PASS n={n} vertices={len(V)} edges={len(E)} triples={len(T)} optimum={target} nodes={nodes}',flush=True)

# Literal lower-witness sizes through n=20 (not an upper proof).
for n in range(4,21):
    V=words(n);vs=set(V)
    cnt=sum(v&7==0 and (v^(1<<i)) in vs for v in V for i in range(3))
    require(cnt==F[n]+F[n-2],('lift count',n,cnt))
print('PASS lower construction literal edge counts n=4..20')

# Gaps count by first and last neighboring bits; all integer arithmetic.
def options(g,a,b):
    if g==1:return [(b,a,1)] if not a*b else []
    if g==2:return [(p,p,1) for p in (0,1) if not(a*p or p*b)]
    return [(p,q,F[g-1-p-q]) for p,q in product((0,1),repeat=2) if not(a*p or q*b) and F[g-1-p-q]]

def slot(gaps,b):
    d=len(b);total=0
    for opts in product(*(options(g,a,c) for g,a,c in zip(gaps,b,b[1:]+b[:1]))):
        avail=sum(not(opts[j-1][1] or opts[j][0]) for j in range(d))
        total+=prod(w for _,_,w in opts)*max(1,avail)
    return total

@lru_cache(None)
def flipmasks(n):
    vs=set(words(n))
    return {v:sum(1<<i for i in range(n) if v^(1<<i) in vs) for v in vs}

# Independently enumerate full legal vertices and actual possible flips.
d=4;count=0;minimum=None;zero=[]
for gs in product(range(1,5),repeat=d):
    n=sum(gs);I=[0]
    for g in gs[:-1]:I.append(I[-1]+g)
    M=sum(1<<i for i in I);N=flipmasks(n);hist=Counter()
    for v,flips in N.items():hist[v&M]+=max(1,(flips&M).bit_count())
    for b in product((0,1),repeat=d):
        B=sum(x<<i for x,i in zip(b,I))
        val=slot(gs,b)
        require(val==hist[B],('slot formula',gs,b,val,hist[B]))
        feas=not any(g==1 and (b[j] or b[(j+1)%d]) for j,g in enumerate(gs))
        require(feas==(B in N and N[B]&M==M),('center feasibility',gs,b))
        if not feas:continue
        margin=F[n]+F[n-2]-val-slot(gs,tuple(1-v for v in b))
        require(margin>=0,('margin',gs,b,margin));count+=1
        minimum=margin if minimum is None else min(minimum,margin)
        if not margin:zero.append((gs,b))
require((count,minimum,zero)==(1831,0,[((1,1,1,1),(0,0,0,0))]),('base summary',count,minimum,zero))
print('PASS four-arm capacity bases=1831 min_margin=0 only_zero_dimension=4 all_histograms_vs_literal_flips')
# Three arms, at least one cyclic gap 1. The same recurrence preserves that gap.
d=3;count=0;minimum=None;zeros=0
for gs in product(range(1,5),repeat=d):
    if 1 not in gs:continue
    n=sum(gs);I=[0,gs[0],gs[0]+gs[1]];M=sum(1<<i for i in I);N=flipmasks(n);hist=Counter()
    for v,flips in N.items():hist[v&M]+=max(1,(flips&M).bit_count())
    for b in product((0,1),repeat=d):
        B=sum(x<<i for x,i in zip(b,I));val=slot(gs,b)
        require(val==hist[B],('three-slot formula',gs,b))
        feas=not any(g==1 and (b[j] or b[(j+1)%d]) for j,g in enumerate(gs))
        require(feas==(B in N and N[B]&M==M),('three-center feasibility',gs,b))
        if not feas:continue
        margin=F[n]+F[n-2]-val-slot(gs,tuple(1-v for v in b))
        require(margin>=0,('three-margin',gs,b,margin));count+=1
        minimum=margin if minimum is None else min(minimum,margin);zeros+=not margin
require((count,minimum,zeros)==(64,0,10),'three summary')
print('PASS adjacent-three-arm capacity bases=64 min_margin=0 zero_margins=10')
print('FINAL PASS / FINITE CERTIFICATES / GENERAL LOWER AND CONDITIONAL UPPER REQUIRE PROOF AUDIT / PRIVATE HOLD')
