# No.76 candidate v0.1 — A lower bound and star-capacity upper bounds for edge general position in Lucas cubes

PRIVATE HOLD. Preliminary results, not a completed all-dimension classification. NOVELTY INCONCLUSIVE / REFERENCES PARTIAL. No independent audit, Windows test, or human peer review performed. No.75 is unchanged; Section 2 below is reproduced as a self-contained argument, so this result does not depend on acceptance of No.75's Fibonacci cube classification.

## 1. Model and lower bound

Let Lambda_n, n>=3, be the graph of length-n binary words with no cyclically adjacent ones, with adjacency by a single-coordinate flip. Let F_0=0, F_1=1 and F_{r+2}=F_{r+1}+F_r. The cardinality of a largest edge general position set (at most two selected edges on each geodesic) is gp_e. Graph distance equals Hamming distance: remove the ones absent from the target, then insert the missing target ones. Consequently the colors (changed coordinates) on a geodesic are distinct. The number of vertices is the Lucas number F_{n-1}+F_{n+1}.

Klavzar and Tan (2023), Proposition 4.1(ii) and Theorem 4.6, give the coordinate-class size F_{n-1} and lower bound 2F_{n-1} for n>=4. Their Proposition 4.7 establishes gp_e(Lambda_5)=7, showing the lower bound 6 need not be optimal. These results are prior work.

**Theorem A (analytic lower bound).** For every n>=4,

    gp_e(Lambda_n) >= K_n := F_n+F_{n-2} = F_{n-1}+2F_{n-2}.

For n>=5, K_n=2F_{n-1}+F_{n-4}>2F_{n-1}.

Proof. Choose three consecutive cyclic coordinates, say 0,1,2. Select every edge changing one of the three whose other two bits are both zero. Its projection is an arm of the 3-star centered at 000. If a geodesic contains three selected edges, it must change each of the three coordinates once and these are the only changes to its projection. But the resulting 3-step projected walk would use three distinct edges of a star while changing distinct coordinates, impossible: a simple path in a star has length at most two. For the middle coordinate, its two neighbors are fixed zero and the other n-3 coordinates form a free path, giving F_{n-1} edges. For either outer coordinate, the chosen three and one additional neighbor are fixed (before the flip) to zero, leaving a free path of n-4 coordinates, giving F_{n-2} edges each, including n=4. The sum is K_n. For n>=5 the Fibonacci recurrence gives the displayed strict improvement. For n=3 the same construction selects all three edges, and K_3=3. QED.

## 2. Two star lemmas (self-contained; same arguments as in No.75 v0.10)

**Lemma B.** In any isometric subgraph of a hypercube, an edge general position set S using at least three colors induces a star forest on its incident vertices (only selected edges are included).

Proof. A simple 3-edge path in S is forbidden if its colors are distinct. Otherwise its colors are i,j,i. The four vertices realize all four assignments on i,j and agree elsewhere. The oriented length-2 subpaths have all four vertices as possible ending vertices. Choose a selected edge f of a third color k. Choose such a subpath ending at z whose i,j bits agree with the fixed bits of f. Choose endpoint y of f with its k bit equal to that of z. A shortest connector z to y changes none of i,j,k. Concatenating the length-2 subpath, connector, and f gives a walk with distinct changed coordinates throughout, hence a geodesic containing three selected edges, contradiction. The selected graph is bipartite and has no simple path of length 3. Every connected nonempty component must then be a star: two vertices of degree at least 2 would produce adjacent vertices of degree at least 2 (along a shortest connecting path), and these produce a simple 3-edge path in a bipartite graph. QED.

**Lemma C.** Suppose S contains a star centered at v with arms of colors I, where |I|=d>=3. Every selected edge f of color k has fixed bits on I excluding k either all equal to v there, or all opposite to v there.

Proof. Otherwise choose i,j in I excluding k for which exactly one bit disagrees with v. Orient the path v^i--v--v^j so its ending vertex agrees with f on i,j. Choose the endpoint of f that agrees with this ending vertex on k. A shortest connector avoids i,j,k, and the concatenated walk has no repeated changed coordinate, giving a forbidden geodesic. QED.

## 3. Star-capacity upper bound

Fix any d>=3 arms as in Lemma C, and let b be the projection of v to I. Let the core C be all legal words with projection either b or its bitwise complement. For x in C let a(x) count legal edges at x changing a color in I. Each selected edge of color in I joins exactly one core vertex to a noncore vertex: it agrees on the other d-1 coordinates, and since d>=3 the two core projections differ in more than one coordinate. Each selected edge of color outside I has both endpoints in C, by Lemma C.

**Lemma D.** |S| <= sum_{x in C} max(1,a(x)).

Proof. Charge each selected I-colored edge to its unique core endpoint. By Lemma B each selected component is a star. Assign each remaining selected edge (both endpoints core) to one of its leaf endpoints in that star, with an arbitrary orientation for a one-edge component. These recipients are distinct and have no selected I-colored edge, because their degree in S is one. A core vertex receiving an I-colored edge receives at most a(x) charges; a recipient of a core-core edge receives one. QED.

## 4. Exact cyclic counting and finite reduction

List the chosen coordinates cyclically, at successive distances g_0,...,g_{d-1}>=1, with sum n. A core projection b is feasible as a center of a star with those arms exactly when for each g_j=1 both adjacent chosen bits b_j,b_{j+1} are zero (cyclic indexing). Necessity follows from legality of each flip; sufficiency follows by setting all unchosen bits zero.

For fixed endpoint bits a,c of a gap g, record p,q, the bits immediately inside the gap next to the endpoints (for g=1 use p=c,q=a; for g=2 p=q is the same vertex). Legal assignment counts are:

- g=1: one assignment (p,q)=(c,a) if ac=0; otherwise none.
- g=2: one assignment for each p=q in {0,1} with ap=pc=0.
- g>=3: F_{g-1-p-q} assignments for each p,q in {0,1} with ap=qc=0. This follows from the adjacency transfer matrix [[1,1],[1,0]] raised to power g-2; a zero entry means no assignments.

Selections in the distinct gaps are independent with the chosen bits fixed. At chosen coordinate j the flip is legal exactly when q_{j-1}=p_j=0. Thus, for a fixed projection b, the total capacity H(g,b)=sum_{x with projection b} max(1,a(x)) is computed by summing over all gap records the product of their counts multiplied by max(1, number of chosen coordinates with both neighbors zero). The total core capacity is H(g,b)+H(g,1-b).

For any one gap g_j>=5, H satisfies the Fibonacci recurrence as a function of that gap alone: its local factor is F_{g_j-1-p-q}, and both smaller gaps remain >=3, so the same p,q records and factors can be used, with zero counts included. K_n satisfies the same recurrence in that gap. Feasibility of b is unchanged when reducing a gap >=5 to g_j-1 or g_j-2. Therefore margin K_n-H(g,b)-H(g,1-b) obeys the same recurrence. Strong induction on sum g_j reduces margin nonnegativity to gaps in {1,2,3,4}. If one specified gap is 1, it stays 1 throughout reduction.

**Theorem E (computer-assisted conditional upper bound).** For n>=5, if a selected edge general position set contains a star with at least four arms, its cardinality is strictly less than K_n. If it contains a three-arm star whose colors include two cyclically adjacent coordinates, its cardinality is at most K_n.

Proof. For d=4, the verifier checks all 1831 feasible base tuples, with nonnegative margin and the sole zero tuple all gaps one and all center bits zero (n=4). For any reduced tuple with an originally non-base gap, both smaller sums remain >=6, so strictness for n>=5 follows by induction. For d=3 with one or more cyclic gaps equal to one, all 64 feasible base tuples have nonnegative margin. The verifier compares the gap formula against an independent literal enumeration of every legal word and counts actual legal flips, and checks center feasibility by actual flips. Lemma D and the recurrence complete the asserted bounds. QED.

## 5. Finite exact values

The verifier generates forbidden triples in two independent ways: (i) BFS shortest-path DAGs with propagation of single-edge and two-edge prefix subsets; (ii) the three possible middle-edge choices and coordinate monotonicity. Both generate identical forbidden triples. A triple belongs to a shortest path iff some shortest-path DAG contains its three edges in order; all possible initial vertices are used. The monotonicity predicate uses equality of the middle edge and last edge on the first color, equality of the first and middle edge on the last color, opposite first/last fixed bits on the middle color, and absence of repeated coordinate changes outside the three colors. These conditions suffice because oriented endpoints can be joined by shortest connectors in the isometric graph.

Given the forbidden triples, the exact search uses an initially complete pair-compatibility graph on candidate edges. Each included edge makes two remaining edges incompatible if the three form a forbidden triple. After including an edge, candidates must also be its neighbors in the current compatibility graph. This maintains the invariant that a new candidate has no forbidden triple with two already selected edges, and future pairs must satisfy all chosen-edge restrictions. A greedy proper coloring of the current graph gives an upper bound on clique size; sorting vertices by nondecreasing color and branching in reverse order gives a bound for the remaining prefix. If selected count plus color bound or candidate count cannot beat the known witness, the branch is safely pruned. Otherwise all include/exclude choices are explored (exclusions proceed by deletion from the prefix). This is an integer-only exhaustive proof of no larger set, not a numerical solver assertion.

The computed exact optima are n=3..9: 3,4,7,11,18,29,47, all equal to K_n. The n=5 result is already in the primary reference; no novelty claimed for it. Exact upper bounds for n>=10 are not established here. Verification of witness counts through 20 is only a consistency check on the analytic lower bound, not an upper-bound proof.

## 6. Remaining work and literature

For a set using <=2 colors, its size is <=2F_{n-1}, strictly below K_n for n>=5. For a star forest of maximum degree one, the matching bound |S|<=|V|/2<K_n applies since |V|=F_{n-1}+F_{n+1}<2(F_n+F_{n-2}). Theorem E covers maximum degree >=4, and a degree-3 star containing adjacent colors. The remaining cases are star forests of maximum degree 2 using at least 3 colors, or maximum degree 3 where every 3-arm star has pairwise nonadjacent colors. Therefore the conjecture gp_e(Lambda_n)=K_n for all n>=4 is NOT proved. n=10 exact search was attempted outside this verifier but did not finish within the short time limit; it is not an impossibility result. No.75's frozen manuscript remains unmodified and is not required by the verification.

Primary reference: S. Klavzar and E. Tan, Edge General Position Sets in Fibonacci and Lucas Cubes, Bull. Malays. Math. Sci. Soc. 46:120 (2023), DOI 10.1007/s40840-023-01517-y. Consulted publisher HTML, especially Proposition 4.1(ii), Theorem 4.6 and Proposition 4.7. Also located subsequent general-position survey and related papers, with no direct match for the present general lower construction found in targeted searches. No exhaustive novelty assessment performed. All mathematical statements here remain subject to independent review.

Run `python -B -I verify.py` in Python 3.10+; output should match EXPECTED_RESULTS.txt. Standard library only.
